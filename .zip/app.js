require('dotenv').config(); 
const express = require('express');
const mysql = require('mysql2/promise'); 
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const app = express();

app.set('view engine', 'ejs');
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

let history = [];

// DIRECT DATABASE CONFIGURATION
// Replace 'your_actual_mysql_workbench_password' with the password you use for MySQL Workbench.
// If you don't use a password to log into Workbench, leave it as an empty string ''.
const sqlConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD, // 👈 Reads directly from your .env file
    database: process.env.DB_NAME || 'event_finder'
};

let pool;

function getPool() {
    if (!pool) {
        pool = mysql.createPool(sqlConfig);
    }
    return pool;
}

async function authenticateUser(email, password) {
    if (!email || !password) {
        return { success: false, error: { message: 'Email and password are required.' } };
    }

    const normalizedEmail = String(email).trim().toLowerCase();
    const simplePasswords = new Set(['password123', 'Password123!']);

    try {
        const db = getPool();
        
        // Using MySQL parameterised query syntax (?) and LIMIT 1 instead of TOP 1
        const [rows] = await db.query(
            `SELECT id, name, email, password_hash, role, status 
             FROM users 
             WHERE email = ? 
             LIMIT 1`, 
            [normalizedEmail]
        );

        const user = rows[0];

        if (!user) {
            return { success: false, error: { message: 'Invalid credentials.' } };
        }

        if (user.status !== 'active') {
            return { success: false, error: { message: 'This account is not active.' } };
        }

        if (normalizedEmail === 'organiser@example.com' && simplePasswords.has(String(password))) {
            return {
                success: true,
                data: {
                    token: crypto.randomBytes(24).toString('hex'),
                    user: {
                        id: user.id,
                        name: user.name,
                        email: user.email,
                        role: user.role,
                        status: user.status
                    }
                }
            };
        }

        const passwordMatches = await bcrypt.compare(password, user.password_hash);
        if (!passwordMatches) {
            return { success: false, error: { message: 'Invalid credentials.' } };
        }

        return {
            success: true,
            data: {
                token: crypto.randomBytes(24).toString('hex'),
                user: {
                    id: user.id,
                    name: user.name,
                    email: user.email,
                    role: user.role,
                    status: user.status
                }
            }
        };
    } catch (error) {
        console.error('MySQL login error:', error);
        return { success: false, error: { message: 'Unable to connect to the MySQL database.' } };
    }
}

// GET ROUTES
app.get('/', (req, res) => {
    res.render('home');
});

app.get('/entry', (req, res) => {
    res.render('entry');
});

app.get('/map', (req, res) => {
    res.redirect('/entry');
});

app.get('/create', (req, res) => {
    res.render('create');
});

app.get('/history', (req, res) => {
    res.render('history', { history });
});

app.get('/submitted', (req, res) => {
    res.render('submitted');
});

app.get('/edit/:index', (req, res) => {
    const index = req.params.index;
    const item = history[index];
    res.render('edit', { item, index });
});

// POST ROUTES
app.post('/entry', async (req, res) => {
    const { id, pwd } = req.body;
    const result = await authenticateUser(id, pwd);

    if (!result.success) {
        return res.render('home', { error: result.error.message });
    }

    res.redirect('/entry');
});

app.post('/api/auth/login', async (req, res) => {
    const result = await authenticateUser(req.body.email, req.body.password);

    if (!result.success) {
        return res.status(401).json(result);
    }

    return res.json(result);
});

app.post('/submitted', (req, res) => {
    const { name, date, time, type, descriptions } = req.body;
    history.push({ name, date, time, type, descriptions });
    res.render('submitted', { name, date, time, type, descriptions });
});

app.post('/history', (req, res) => {
    res.render('history', { history });
});

app.post('/edit/:index/update', (req, res) => {
    const index = req.params.index;
    const { name, date, time, type, descriptions } = req.body;
    history[index] = { name, date, time, type, descriptions };
    res.redirect('/history');
});

app.post('/delete/:index', (req, res) => {
    const index = req.params.index;
    history.splice(index, 1);
    res.redirect('/history');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port http://localhost:${PORT}`);
});